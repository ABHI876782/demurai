DIMURAI — READY PROJECT
=======================

Professor, this folder is already arranged as an Android Studio project.

WHAT YOU DO:
1. Extract the ZIP.
2. Open Android Studio.
3. Choose "Open".
4. Select the extracted "Dimurai" folder.
5. Wait for Gradle Sync to finish.
6. Connect your Android phone with USB debugging ON, or use an emulator.
7. Press Run ▶.
8. Give microphone/notification permissions when Android asks.

IMPORTANT:
- You do NOT need to create MainActivity.kt yourself.
- You do NOT need activity_main.xml.
- All Dimurai Kotlin logic is kept in ONE Kotlin file.
- AndroidManifest.xml is the only required separate configuration file.
- The project contains the current wake-word/background-service build.

APP:
Dimurai

PACKAGE:
com.dimurai.assistant

WAKE WORD:
"Dimurai"

EXAMPLE:
"Dimurai"
then
"Open YouTube"

Also supported:
"Dimurai open YouTube"
