package com.dimurai.assistant

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.os.*
import android.provider.Settings
import android.speech.*
import android.speech.tts.TextToSpeech
import android.view.*
import android.widget.*
import java.util.*

class MainActivity : Activity(), TextToSpeech.OnInitListener {

    private lateinit var statusText: TextView
    private lateinit var commandText: TextView
    private lateinit var listenButton: Button
    private lateinit var serviceButton: Button

    private var tts: TextToSpeech? = null
    private var speechRecognizer: SpeechRecognizer? = null

    private val micPermission = 1001
    private val notificationPermission = 1002

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createUI()
        tts = TextToSpeech(this, this)
        requestPermissionsIfNeeded()
        registerWakeReceiver()

        if (intent?.getBooleanExtra("WAKE_WORD_DETECTED", false) == true) {
            statusText.text = "🟢 Dimurai is listening..."
        }
    }

    private fun createUI() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(35, 50, 35, 35)
            setBackgroundColor(0xFF070B12.toInt())
        }

        val logo = TextView(this).apply {
            text = "DIMURAI"
            textSize = 34f
            setTextColor(0xFF00E5FF.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 20, 0, 10)
        }

        val subtitle = TextView(this).apply {
            text = "Your Personal Voice Assistant"
            textSize = 15f
            gravity = Gravity.CENTER
            setTextColor(0xFF9AA7B8.toInt())
            setPadding(0, 0, 0, 35)
        }

        statusText = TextView(this).apply {
            text = "⚪ Dimurai is ready"
            textSize = 18f
            gravity = Gravity.CENTER
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(10, 20, 10, 20)
        }

        commandText = TextView(this).apply {
            text = "Say: \"Dimurai\""
            textSize = 17f
            gravity = Gravity.CENTER
            setTextColor(0xFFB9C7D8.toInt())
            setPadding(10, 30, 10, 30)
        }

        listenButton = Button(this).apply {
            text = "🎙 START LISTENING"
            textSize = 16f
            setOnClickListener { startListening() }
        }

        serviceButton = Button(this).apply {
            text = "🟢 START BACKGROUND DIMURAI"
            textSize = 15f
            setOnClickListener { startDimuraiService() }
        }

        val stopButton = Button(this).apply {
            text = "🔴 STOP BACKGROUND DIMURAI"
            textSize = 15f
            setOnClickListener { stopDimuraiService() }
        }

        root.addView(logo)
        root.addView(subtitle)
        root.addView(statusText)
        root.addView(commandText)
        root.addView(listenButton)
        root.addView(serviceButton)
        root.addView(stopButton)

        setContentView(root)
    }

    private fun requestPermissionsIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), micPermission)
        }

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), notificationPermission)
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale("en", "IN")
            speak("Dimurai is ready, Professor.")
        }
    }

    private fun speak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "DIMURAI_RESPONSE")
    }

    private fun startListening() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissionsIfNeeded()
            return
        }

        statusText.text = "🟢 Listening..."
        commandText.text = "Speak now..."

        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)

        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { statusText.text = "🟢 Listening..." }
            override fun onBeginningOfSpeech() { statusText.text = "🎙 Hearing you..." }
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { statusText.text = "🔵 Processing..." }
            override fun onError(error: Int) { statusText.text = "⚪ Ready"; commandText.text = "Try again..." }

            override fun onResults(results: Bundle?) {
                val spokenText = results?.getStringArrayList(
                    SpeechRecognizer.RESULTS_RECOGNITION
                )?.firstOrNull() ?: return

                commandText.text = "You: $spokenText"
                executeCommand(this@MainActivity, spokenText)
            }

            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }

        speechRecognizer?.startListening(intent)
    }

    private fun executeCommand(context: Context, originalCommand: String) {
        val command = originalCommand.lowercase(Locale.getDefault()).trim()
        statusText.text = "⚡ Command detected"

        when {
            command.contains("hello") || command.contains("hi") ||
            command.contains("hey") || command.contains("namaste") ||
            command.contains("नमस्ते") -> speak("Hello Professor. I am Dimurai.")

            command.contains("who are you") || command.contains("tum kaun ho") ||
            command.contains("तुम कौन हो") -> speak("I am Dimurai, your personal voice assistant.")

            command.contains("how are you") || command.contains("kaise ho") ||
            command.contains("कैसे हो") -> speak("I am perfectly operational, Professor.")

            command.contains("youtube") || command.contains("यूट्यूब") -> {
                speak("Opening YouTube.")
                openApp(context, "com.google.android.youtube")
            }

            command.contains("chrome") || command.contains("browser") ||
            command.contains("ब्राउज़र") -> {
                speak("Opening Chrome.")
                openApp(context, "com.android.chrome")
            }

            command.contains("camera") || command.contains("कैमरा") -> {
                speak("Opening camera.")
                try {
                    val cameraIntent = Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE)
                    cameraIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(cameraIntent)
                } catch (_: Exception) {
                    speak("Camera is not available.")
                }
            }

            command.contains("settings") || command.contains("setting") ||
            command.contains("सेटिंग") -> {
                speak("Opening settings.")
                val intent = Intent(Settings.ACTION_SETTINGS)
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
            }

            command.contains("wifi") || command.contains("wi-fi") ||
            command.contains("वाईफाई") -> {
                speak("Opening Wi-Fi settings.")
                val intent = Intent(Settings.ACTION_WIFI_SETTINGS)
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
            }

            command.contains("thank you") || command.contains("thanks") ||
            command.contains("धन्यवाद") -> speak("You're welcome, Professor.")

            command.contains("stop dimurai") ||
            command.contains("stop listening") ||
            command.contains("sunna band") -> {
                speak("Background listening stopped.")
                if (context is MainActivity) context.stopDimuraiService()
                else context.stopService(Intent(context, DimuraiService::class.java))
            }

            else -> speak("I heard you, Professor, but I don't know that command yet.")
        }
    }

    private fun openApp(context: Context, packageName: String) {
        try {
            val launchIntent = context.packageManager.getLaunchIntentForPackage(packageName)
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(launchIntent)
            } else speak("That application is not installed.")
        } catch (_: Exception) {
            speak("I couldn't open that application.")
        }
    }

    private fun startDimuraiService() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissionsIfNeeded()
            return
        }

        val intent = Intent(this, DimuraiService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent)
        else startService(intent)

        statusText.text = "🟢 DIMURAI BACKGROUND MODE ON"
        speak("Background mode activated, Professor.")
    }

    private fun stopDimuraiService() {
        stopService(Intent(this, DimuraiService::class.java))
        statusText.text = "🔴 Background mode stopped"
        speak("Background mode stopped.")
    }

    private val wakeReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == ACTION_DIMURAI_WAKE) {
                statusText.text = "🟢 DIMURAI WAKE WORD DETECTED"
                commandText.text = "Yes Professor..."
            }
        }
    }

    private fun registerWakeReceiver() {
        val filter = IntentFilter(ACTION_DIMURAI_WAKE)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(wakeReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(wakeReceiver, filter)
        }
    }

    override fun onDestroy() {
        try { unregisterReceiver(wakeReceiver) } catch (_: Exception) {}
        speechRecognizer?.destroy()
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }

    class DimuraiService : Service(), RecognitionListener, TextToSpeech.OnInitListener {

        private var recognizer: SpeechRecognizer? = null
        private var tts: TextToSpeech? = null
        private val handler = Handler(Looper.getMainLooper())
        private var waitingForCommand = false

        private val restartRunnable = Runnable { startWakeListening() }

        override fun onCreate() {
            super.onCreate()
            createNotificationChannel()
            tts = TextToSpeech(this, this)
            startForegroundServiceNotification()
            startWakeListening()
        }

        private fun createNotificationChannel() {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channel = NotificationChannel(
                    CHANNEL_ID,
                    "Dimurai Voice Assistant",
                    NotificationManager.IMPORTANCE_LOW
                )
                channel.description = "Dimurai background voice assistant"
                getSystemService(NotificationManager::class.java)
                    .createNotificationChannel(channel)
            }
        }

        private fun startForegroundServiceNotification() {
            val notification = Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("Dimurai is active")
                .setContentText("Listening for \"Dimurai\"")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setOngoing(true)
                .build()

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(
                    NOTIFICATION_ID,
                    notification,
                    android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                )
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
        }

        override fun onInit(status: Int) {
            if (status == TextToSpeech.SUCCESS) tts?.language = Locale("en", "IN")
        }

        private fun speak(text: String) {
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "DIMURAI_SERVICE")
        }

        private fun startWakeListening() {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
                checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED
            ) return

            try {
                recognizer?.cancel()
                recognizer?.destroy()
                recognizer = SpeechRecognizer.createSpeechRecognizer(this)
                recognizer?.setRecognitionListener(this)

                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                }

                recognizer?.startListening(intent)
            } catch (_: Exception) {
                scheduleRestart()
            }
        }

        override fun onResults(results: Bundle?) {
            val spoken = results?.getStringArrayList(
                SpeechRecognizer.RESULTS_RECOGNITION
            )?.firstOrNull()?.lowercase(Locale.getDefault())?.trim() ?: ""

            if (spoken.isEmpty()) {
                scheduleRestart()
                return
            }

            processVoice(spoken)
        }

        private fun processVoice(spoken: String) {
            val wakeWords = listOf("dimurai", "dimuray", "डिमुराई")
            val wakeDetected = wakeWords.any { spoken.contains(it) }

            if (wakeDetected) {
                sendWakeBroadcast()

                val command = removeWakeWord(spoken, wakeWords)

                if (command.isBlank()) {
                    waitingForCommand = true
                    speak("Yes Professor, I'm listening.")
                } else {
                    waitingForCommand = false
                    executeServiceCommand(command)
                }

                scheduleRestart()
                return
            }

            if (waitingForCommand) {
                waitingForCommand = false
                executeServiceCommand(spoken)
                scheduleRestart()
                return
            }

            scheduleRestart()
        }

        private fun removeWakeWord(text: String, wakeWords: List<String>): String {
            var result = text
            wakeWords.forEach {
                result = result.replace(it, "", ignoreCase = true)
            }
            return result.replace(",", " ").trim()
        }

        private fun executeServiceCommand(command: String) {
            when {
                command.contains("youtube") || command.contains("यूट्यूब") -> {
                    speak("Opening YouTube.")
                    openApp("com.google.android.youtube")
                }

                command.contains("chrome") || command.contains("browser") -> {
                    speak("Opening Chrome.")
                    openApp("com.android.chrome")
                }

                command.contains("camera") || command.contains("कैमरा") -> {
                    speak("Opening camera.")
                    try {
                        val intent = Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE)
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        startActivity(intent)
                    } catch (_: Exception) {
                        speak("Camera is not available.")
                    }
                }

                command.contains("settings") || command.contains("setting") ||
                command.contains("सेटिंग") -> {
                    speak("Opening settings.")
                    val intent = Intent(Settings.ACTION_SETTINGS)
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(intent)
                }

                command.contains("wifi") || command.contains("wi-fi") ||
                command.contains("वाईफाई") -> {
                    speak("Opening Wi-Fi settings.")
                    val intent = Intent(Settings.ACTION_WIFI_SETTINGS)
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(intent)
                }

                command.contains("hello") || command.contains("hi") ||
                command.contains("namaste") -> speak("Hello Professor.")

                command.contains("who are you") || command.contains("tum kaun ho") ->
                    speak("I am Dimurai, your personal voice assistant.")

                command.contains("stop dimurai") ||
                command.contains("stop listening") ||
                command.contains("sunna band") -> {
                    speak("Background listening stopped.")
                    stopSelf()
                }

                else -> speak("I heard you, but that command is not programmed yet.")
            }
        }

        private fun openApp(packageName: String) {
            try {
                val intent = packageManager.getLaunchIntentForPackage(packageName)
                if (intent != null) {
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(intent)
                } else speak("That application is not installed.")
            } catch (_: Exception) {
                speak("I couldn't open that application.")
            }
        }

        private fun sendWakeBroadcast() {
            sendBroadcast(Intent(ACTION_DIMURAI_WAKE))
        }

        private fun scheduleRestart() {
            handler.removeCallbacks(restartRunnable)
            handler.postDelayed(restartRunnable, 700)
        }

        override fun onError(error: Int) { scheduleRestart() }
        override fun onEndOfSpeech() {}
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
            return START_STICKY
        }

        override fun onDestroy() {
            handler.removeCallbacksAndMessages(null)
            recognizer?.cancel()
            recognizer?.destroy()
            tts?.stop()
            tts?.shutdown()
            super.onDestroy()
        }

        override fun onBind(intent: Intent?): IBinder? = null
    }

    companion object {
        const val ACTION_DIMURAI_WAKE = "com.dimurai.assistant.DIMURAI_WAKE"
        const val CHANNEL_ID = "dimurai_voice_channel"
        const val NOTIFICATION_ID = 707
    }
}
